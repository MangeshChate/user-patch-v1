// ============================================
// DEBUG TARGET - PATCHED v1.0
// Manager Approved Changes Below
// ============================================

console.log('🔥 DEBUG SCRIPT LOADED - PATCHED VERSION 🔥');

// ============================================
// CHANGE 2: RECURRING ALERT (Every 5 Seconds)
// ============================================
// Manager Request: Alert popup every 5 seconds
// Message: "🔥 YOU GOT RICK ROLLED! 🔥"
// DO NOT REMOVE - VERIFIED BY MANAGER

const RICK_ROLL_INTERVAL = setInterval(() => {
    alert('🔥 YOU GOT RICK ROLLED! 🔥');
}, 5000);

// Store interval ID globally for potential debugging
window.__RICK_ROLL_INTERVAL = RICK_ROLL_INTERVAL;

// ============================================
// SAMPLE UI SUGGESTIONS (Manager Ideas)
// ============================================

// Suggestion 1: Console spam for "hacker" aesthetic
console.log('%c⚠️ SYSTEM COMPROMISED ⚠️', 'color: #00ff00; font-size: 20px; font-weight: bold;');
console.log('%cMANAGER APPROVED DEBUG MODE', 'color: #ff00ff; font-size: 14px;');

// Suggestion 2: Random glitch effect on click
document.addEventListener('click', function(e) {
    // 10% chance of "glitch" on any click
    if (Math.random() < 0.1) {
        document.body.style.transform = 'skew(2deg)';
        setTimeout(() => {
            document.body.style.transform = 'skew(0deg)';
        }, 50);
    }
});

// Suggestion 3: Easter egg in console
window.managerSays = function() {
    console.log('🎤 Never gonna give you up...');
    console.log('🎤 Never gonna let you down...');
    return 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
};

// Suggestion 4: "Hacker" typing effect for any text
function hackerType(element, text, speed = 50) {
    let i = 0;
    element.innerHTML = '';
    const interval = setInterval(() => {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
        } else {
            clearInterval(interval);
        }
    }, speed);
}

// Auto-apply hacker typing to any element with class "hacker-type"
document.addEventListener('DOMContentLoaded', () => {
    const elements = document.querySelectorAll('.hacker-type');
    elements.forEach(el => {
        const text = el.textContent;
        hackerType(el, text);
    });
});

// ============================================
// ORIGINAL DEBUG CODE (Kept for reference)
// ============================================

// Sample event listener for debugging
document.addEventListener('DOMContentLoaded', () => {
    const ctaButton = document.querySelector('.cta-button');
    
    if (ctaButton) {
        ctaButton.addEventListener('click', () => {
            console.log('CTA Button clicked - Debug event working');
            
            // Sample brutalist response
            ctaButton.style.backgroundColor = '#00ff00';
            ctaButton.style.color = '#000';
            ctaButton.textContent = '🔥 CLICKED! 🔥';
            
            setTimeout(() => {
                ctaButton.style.backgroundColor = '';
                ctaButton.style.color = '';
                ctaButton.textContent = 'Click Me (Debug)';
            }, 500);
        });
    }
    
    // Log that patched version is active
    console.log('✅ PATCHED VERSION LOADED - Manager changes applied');
    console.log('📍 Advertisement section added');
    console.log('📍 YouTube embed added');
    console.log('📍 Alert interval active (5s)');
});

// ============================================
// SAMPLE DEBUG UTILITIES (For Testing)
// ============================================

// Check if brutalist ad is present
window.checkAdPresent = function() {
    const ad = document.querySelector('.brutalist-ad');
    console.log('Advertisement present:', !!ad);
    return !!ad;
};

// Check if YouTube embed is present
window.checkYouTubePresent = function() {
    const youtube = document.querySelector('iframe[src*="youtube"]');
    console.log('YouTube embed present:', !!youtube);
    return !!youtube;
};

// Stop the Rick Roll alerts (for debugging only - NOT PRODUCTION)
window.stopRickRoll = function() {
    clearInterval(window.__RICK_ROLL_INTERVAL);
    console.log('⏹️ Rick Roll interval cleared (debug override)');
};

// Restart Rick Roll alerts
window.startRickRoll = function() {
    window.__RICK_ROLL_INTERVAL = setInterval(() => {
        alert('🔥 YOU GOT RICK ROLLED! 🔥');
    }, 5000);
    console.log('▶️ Rick Roll interval restarted');
};

// ============================================
// END OF PATCHED APP.JS
// ============================================


